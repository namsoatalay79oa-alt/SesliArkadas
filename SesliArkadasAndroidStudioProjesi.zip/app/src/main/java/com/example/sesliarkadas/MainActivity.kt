package com.example.sesliarkadas

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.util.Locale

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private var tts: TextToSpeech? = null
    private var recognizer: SpeechRecognizer? = null
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(32, 32, 32, 32)
        }
        status = TextView(this).apply {
            text = "Merhaba! Ben Sesli Arkadaş. Başlamak için düğmeye bas ve konuş."
            textSize = 20f
            gravity = Gravity.CENTER
        }
        val button = Button(this).apply {
            text = "🎙 Konuş"
            setOnClickListener { listen() }
        }
        layout.addView(status)
        layout.addView(button)
        setContentView(layout)
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 10)
        }
        if (SpeechRecognizer.isRecognitionAvailable(this)) {
            recognizer = SpeechRecognizer.createSpeechRecognizer(this)
            recognizer?.setRecognitionListener(object : android.speech.RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) { status.text = "Seni dinliyorum…" }
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onError(error: Int) { status.text = "Ses algılanamadı. Yeniden deneyebilirsin." }
                override fun onResults(results: Bundle?) {
                    val said = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
                    handle(said.lowercase(Locale("tr", "TR")))
                }
                override fun onPartialResults(partialResults: Bundle?) {}
                override fun onEvent(eventType: Int, params: Bundle?) {}
            })
        }
    }

    private fun listen() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 10); return
        }
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "tr-TR")
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Söyle, seni dinliyorum")
        }
        try { recognizer?.startListening(intent) } catch (_: Exception) {
            status.text = "Ses tanıma başlatılamadı."
        }
    }

    private fun handle(command: String) {
        status.text = "Sen: $command"
        when {
            command.contains("selam") || command.contains("merhaba") ->
                say("Merhaba! Buradayım. Bugün nasıl yardımcı olayım?")
            command.contains("nasılsın") ->
                say("İyiyim, teşekkür ederim. Sen nasılsın?")
            command.contains("saat kaç") -> {
                val now = java.text.SimpleDateFormat("HH:mm", Locale("tr", "TR")).format(java.util.Date())
                say("Saat $now")
            }
            command.contains("youtube aç") -> openUrl("https://www.youtube.com")
            command.contains("google aç") || command.contains("internet aç") -> openUrl("https://www.google.com")
            command.contains("arama ekranı") || command.contains("telefon aç") ->
                startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:")))
            command.contains("ayarları aç") -> startActivity(Intent(android.provider.Settings.ACTION_SETTINGS))
            command.contains("yardım") -> say("Merhaba diyebilirsin, saati sorabilir, Google, YouTube veya telefon arama ekranını açmamı isteyebilirsin.")
            else -> say("Komutu anladım: $command. Şimdilik çevrimdışı temel komutlarla çalışıyorum. Serbest yapay zekâ sohbeti için güvenli bir yapay zekâ API bağlantısı eklenmeli.")
        }
    }

    private fun openUrl(url: String) {
        try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))); say("Açıyorum.") }
        catch (_: Exception) { say("Bu uygulama açılamadı.") }
    }

    private fun say(text: String) {
        status.text = text
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "sesli_arkadas")
    }

    override fun onInit(statusCode: Int) {
        if (statusCode == TextToSpeech.SUCCESS) {
            val result = tts?.setLanguage(Locale("tr", "TR"))
            if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                Toast.makeText(this, "Türkçe ses paketi telefonda kurulu olmayabilir.", Toast.LENGTH_LONG).show()
            }
            say("Sesli Arkadaş hazır. Konuş düğmesine basabilirsin.")
        }
    }

    override fun onDestroy() {
        recognizer?.destroy()
        tts?.shutdown()
        super.onDestroy()
    }
}
